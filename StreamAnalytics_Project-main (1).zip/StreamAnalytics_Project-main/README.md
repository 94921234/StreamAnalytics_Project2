# StreamAnalytics_Project

Group 04 — Real-Time Food Delivery Analytics
IE University | Stream Analytics | Spring 2026

This repository contains the full implementation of our Stream Analytics project, simulating a real-time food delivery platform (Uber Eats style) with synthetic data generation, event streaming, stream processing, and a live analytics dashboard.

---

## Project overview

We simulate an **Uber Eats food delivery platform** with two event streams:

- **Order events** — full lifecycle from order creation to delivery or cancellation
- **Courier events** — courier availability, assignment, movement, and status updates

The project is divided into two milestones:

| Milestone | Focus | Status |
|-----------|-------|--------|
| M1 — Data Generation | Synthetic event generator (JSON + Avro) | ✅ Complete |
| M2 — Stream Analytics | Ingestion → Spark → Storage → Dashboard | ✅ Complete |

---

## Team

| Member | Contribution |
|--------|-------------|
| Sarah Coste | Repository README and documentation |
| Marta Bermejo, Roberto Falcato | Feed design and schema definition (Avro schemas) |
| Ignacio Ascanio, Javier Sanchez | Generator implementation + M2 pipeline |
| Beatriz Cruces | Sample data generation and Avro serialization |

---

## Repository structure

```
StreamAnalytics_Project/
├── docs/
│   └── feed_design.md              # Feed specification and field explanations
├── schemas/
│   ├── order_events.avsc           # Avro schema for order events
│   └── courier_events.avsc         # Avro schema for courier events
├── generator/                      # M1: synthetic event generator
│   ├── main.py                     # CLI entrypoint
│   ├── generator.py                # Core event generation logic (orders + couriers + edge cases)
│   ├── config.py                   # Generator configuration (entity counts, demand settings)
│   ├── demand_model.py             # Demand model + Madrid traffic model
│   ├── models.py                   # Enums, Madrid zones, entity pools
│   └── serialize_samples.py        # Converts sample JSONL to Avro
├── sample_data/                    # Sample JSON and Avro batches generated for submission
├── milestone2/                     # M2: stream analytics pipeline
│   ├── README.md                   # M2-specific setup and run instructions
│   ├── docs/
│   │   └── 2.1_ingestion_design.md # Event Hubs topic design and architecture decisions
│   ├── producer/
│   │   ├── eventhub_producer.py    # Streams M1 generator output → Azure Event Hubs
│   │   └── requirements.txt        # Producer dependencies
│   ├── streaming/
│   │   └── spark_streaming.py      # Spark Structured Streaming + UC1/UC2/UC3
│   └── dashboard/
│       ├── streamlit_app.py        # Live Streamlit dashboard (reads from Blob Storage)
│       └── requirements.txt        # Dashboard dependencies
└── README.md                       # This file
```

---

## Milestone 1 — Data Generation

### What it does

The generator in `generator/` produces realistic, stream-ready synthetic events for a food delivery platform. Events are emitted in two feeds:

**1) Order Events Feed** (`order_events.avsc`)

Represents the full lifecycle of an order:

- Event types: `ORDER_CREATED`, `ORDER_ACCEPTED`, `PREP_STARTED`, `READY_FOR_PICKUP`, `PICKED_UP`, `DELIVERED`, `CANCELLED`
- Key fields: `event_id` (deduplication), `event_time` (event-time for windowing), `ingest_time` (simulates broker delay), `order_id`, `restaurant_id`, `zone_id`, `courier_id`, `order_value`, `cancel_reason`

**2) Courier Events Feed** (`courier_events.avsc`)

Represents courier availability, assignment, and movement:

- Event types: `COURIER_ONLINE`, `COURIER_OFFLINE`, `COURIER_ASSIGNED`, `COURIER_ARRIVED_PICKUP`, `COURIER_ARRIVED_DROPOFF`, `COURIER_LOCATION`
- Key fields: `event_id`, `event_time`, `ingest_time`, `courier_id`, `zone_id`, `order_id`, `lat`, `lon`, `vehicle_type` (BIKE / SCOOTER / CAR)

The separation between `event_time` and `ingest_time` allows Spark to apply event-time windows and watermarks. Late or out-of-order events are handled using watermarking on `event_time`.

### Realism features

- Lunch/dinner demand peaks + surge multipliers
- Weekend demand multiplier
- Promotion periods (e.g., lunch deal / dinner special)
- Madrid zone skew (zones have different demand weights)
- Madrid traffic model affecting transit times (rush hours, vehicle type multipliers)

### Edge cases (configurable in `config.py`)

- Out-of-order / late arrivals (`ingest_time > event_time`)
- Duplicate events (same `event_id` emitted twice)
- Missing lifecycle step (skips a state in the order FSM)
- Impossible durations (for anomaly detection)
- Courier offline mid-delivery

### How to run the generator

```bash
cd generator
pip install fastavro
python main.py
```

---

## Milestone 2 — Stream Analytics

### Architecture

```
Event Hubs (group04_orders + group04_courierevents)
  └─► Spark Structured Streaming  (milestone2/streaming/spark_streaming.py)
        └─► Azure Blob Storage — Parquet metrics  (wasbs://group04@iesstsabbadbab/)
              └─► Streamlit Dashboard  (milestone2/dashboard/streamlit_app.py)
```

### Azure resources (provisioned by the professor — shared with all groups)

| Resource | Value |
|----------|-------|
| Storage Account | `iesstsabbadbab` |
| Container | `group04` |
| Event Hubs namespace | `iesstsabbadbab-grp-01-05` |
| Resource Group | `SA_BBADBA2025NBDA_B` |

### Use cases implemented

| UC | Type | Description |
|----|------|-------------|
| UC1 | Basic | Orders per zone per minute (1-min tumbling window) |
| UC2 | Intermediate | Demand vs supply imbalance per zone (stream–stream join) |
| UC3 | Advanced | Surge indicator: demand/supply ratio > 1.5 AND demand ≥ 3 |

### Running the project

See **[milestone2/README.md](milestone2/README.md)** for the full step-by-step guide, including:

- How to get credentials from Azure Portal
- Option A: View the live dashboard only (no setup needed)
- Option B: Run the full pipeline locally (producer + Spark + dashboard)
- Option C: Use GitHub Codespace (same environment, zero configuration)

### Live dashboard

The dashboard is deployed and running at:

> **https://glorious-adventure-v66qrwvw6prqhqx-8501.app.github.dev/**

No login or credentials required. Auto-refreshes every 30 seconds with real data from Azure Blob Storage.
